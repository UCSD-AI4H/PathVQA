[toc]

### evaluator.py

#### evaluator

Input candidate sentence (str), some references sentence (list of str), value of n (the length of subsentence) and weights (every weights of p).

### utils.py

#### bervity_penalty

 Calculate the penalty item of BLEU.

#### modified_precision

Calculate the P of BLEU.

#### split_sentence

Split sentence based on the value of n. 

### similarity.py

#### bleu

Pre-calculate BLEU.

#### calculate_bleu

Calculate BLEU.

### API.py

To use the one in the API1 file directory, you have to run API.py first, then run the test.py

To use the one in the API2 file directory, you have to run API.py, and then click the blue web connection.