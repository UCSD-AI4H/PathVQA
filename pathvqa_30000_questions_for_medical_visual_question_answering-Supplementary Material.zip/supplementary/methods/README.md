# Folder with baselines models


This folder contains code to implement the basline models.

[Multimodal Compact Bilinear Pooling for Visual Question Answering and Visual Grounding](https://arxiv.org/abs/1606.01847)

[Stacked Attention Networks for Image Question Answering](https://arxiv.org/pdf/1511.02274.pdf)

[Bilinear Attention Networks](http://arxiv.org/abs/1805.07932)
